using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;


public class SpawnCrowd : MonoBehaviour
{
    
    [SerializeField] GameObject obj;
    int numPeople = 25;

    float averageSpeed = 10f;
    float medianSpeed = 7f;

    float averageMass = 5f;
    float medianMass = 2f;

    float averageVolume = 1f;
    float medianVolume = 0.5f;


    float volume;
    Vector3 position;
//-8, 7 x
//-5, 5 y

    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < numPeople -1; i++)
        {
            position = new Vector3(
                Random.Range(-8f,7f),
                Random.Range(-5f,5f),
                0
                );


        

            obj.GetComponent<Rigidbody2D>().mass = Random.Range(averageMass-medianMass, averageMass+medianMass);
            
            obj.GetComponent<NavMeshAgent>().speed = Random.Range(averageSpeed-medianSpeed, averageSpeed+medianSpeed);

            volume = Random.Range(averageVolume-medianVolume, averageVolume+medianVolume);
            obj.transform.localScale = new Vector3(volume, volume, 1);

            Instantiate(obj, position, Quaternion.identity);
        }
    }

    

    // Update is called once per frame
    void Update()
    {
        
    }
}
